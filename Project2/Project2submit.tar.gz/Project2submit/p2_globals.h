#ifndef P2_GLOBALS_H
#define P2_GLOBALS_H

// number of Ordered_list objects in existence
extern int g_Ordered_list_count;
// number of Ordered_list::Node objects in existence
extern int g_Ordered_list_Node_count;

#endif
