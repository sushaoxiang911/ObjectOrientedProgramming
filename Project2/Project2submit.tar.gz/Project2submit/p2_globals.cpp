#include "p2_globals.h"

int g_Ordered_list_count = 0;
int g_Ordered_list_Node_count = 0;
