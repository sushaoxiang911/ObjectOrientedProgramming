#include "Sim_object.h"

Sim_object::Sim_object(const std::string& name_)
                        :name(name_)
{}

