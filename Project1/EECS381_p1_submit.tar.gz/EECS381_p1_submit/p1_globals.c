#include "p1_globals.h"

int g_Container_count = 0;
int g_Container_items_in_use = 0;
int g_Container_items_allocated = 0;
int g_string_memory = 0;
