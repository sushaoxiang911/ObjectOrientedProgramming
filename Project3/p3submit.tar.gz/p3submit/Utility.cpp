#include "Utility.h"

extern const int rating_min = 1;

extern const int rating_max = 5;
